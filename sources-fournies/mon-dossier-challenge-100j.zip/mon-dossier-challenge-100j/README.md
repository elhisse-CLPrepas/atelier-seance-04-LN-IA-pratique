﻿# Mon dossier — Challenge 100 jours

Ce dossier rassemble mon travail pendant le Challenge 100 jours : mes objectifs, mes prompts, mes livrables et les preuves de ma progression.

## Mes objectifs

À compléter dans [mon objectif personnel](00-depart-cadrage/objectif-personnel-challenge.md).

## Organisation

- **00-depart-cadrage/** : fiche de départ, objectif personnel et textes à retenir.
- **01-prompts/** : trois prompts du support, prêts à copier et à adapter.
- **03-livrables/** : liste des premiers livrables et productions du Challenge.
  - **guide/** : guides et documents pratiques.
  - **rapport/** : rapports et bilans.
  - **landing-page/** : fichiers de ma page web.
  - **supports-visuels/** : images et supports visuels.
- **04-portfolio-preuves/** : livrables finalisés et preuves de ma progression.
- **05-workflows/** : procédures et étapes de travail.

Les noms des dossiers communs suivent ceux de `simulation-seance-02-coach`. Les espaces `supports-visuels/` et `05-workflows/` sont conservés pour les autres besoins du Challenge.

## Pour commencer

1. Compléter la [fiche de départ](00-depart-cadrage/fiche-depart-candidat.md).
2. Définir mon [objectif personnel](00-depart-cadrage/objectif-personnel-challenge.md).
3. Choisir mes [trois premiers livrables](03-livrables/liste-premiers-livrables.md).
4. Copier un prompt depuis `01-prompts/`, compléter ses champs et l'utiliser avec mon assistant IA.
5. Vérifier chaque résultat, le corriger et le classer dans le dossier adapté.
6. Conserver les preuves de mon travail dans `04-portfolio-preuves/`.

## Prompts disponibles

- [Clarifier mon intention](01-prompts/clarifier-mon-intention.md)
- [Transformer une idée vague en objectif](01-prompts/transformer-une-idee-vague-en-objectif.md)
- [Créer mon premier README](01-prompts/creer-mon-premier-readme.md)

## Livrables attendus

Mes trois livrables prioritaires sont à préciser dans la liste des premiers livrables. Pour chacun, je note son nom, son utilité et son emplacement.

## Règle à retenir

**Le livrable prouve.**

L'IA propose. L'humain contrôle. L'atelier organise. Le livrable prouve.

Retrouver tous les [textes à retenir](00-depart-cadrage/textes-a-retenir.md).

## Source

Les trois fiches de cadrage, les trois prompts et les textes à retenir proviennent du support `support-seance-01-prompts-textes-a-copier (1).html`. Ce README est un guide ajouté pour faciliter l'utilisation du dossier. Les champs personnels restent à compléter.
