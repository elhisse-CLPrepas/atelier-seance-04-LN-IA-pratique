﻿Tu es mon assistant de cadrage pour le Challenge 100 JOURS — Relance 25 SEPTEMBRE 2026 — Formation IA pratique.

À partir des informations suivantes, aide-moi à clarifier mon intention en 10 lignes maximum.

Mon activité actuelle :

Mon objectif pendant les 100 jours :

Ce que je veux produire avec l'IA :

Ma difficulté principale :

Le livrable qui serait une preuve utile :

Réponds avec :
1. une intention claire ;
2. un objectif reformulé ;
3. trois livrables possibles ;
4. une première action simple à faire dans VS Code.
