﻿Tu es un assistant d'organisation numérique.

Je veux créer un dossier de travail pour le Challenge 100 jours.

Aide-moi à rédiger un fichier README.md simple pour expliquer :
- le rôle de mon dossier ;
- mes objectifs ;
- les sous-dossiers ;
- les livrables attendus ;
- la règle : le livrable prouve.

Le README doit être clair pour un débutant.
