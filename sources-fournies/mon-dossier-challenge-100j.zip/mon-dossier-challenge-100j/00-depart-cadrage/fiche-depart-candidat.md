﻿# Fiche de départ candidat

Nom :
Prénom :
Email-ID :
Date :

## 1. Mon activité actuelle


## 2. Pourquoi je rejoins le Challenge 100 jours


## 3. Ce que je veux apprendre à produire avec l'IA


## 4. Ma difficulté principale à dépasser


## 5. Le premier livrable qui serait une preuve utile pour moi


## 6. Ma phrase d'engagement

Pendant ce Challenge, je m'engage à apprendre en produisant, corriger mes livrables, organiser mes fichiers et construire progressivement mon portfolio de preuves.