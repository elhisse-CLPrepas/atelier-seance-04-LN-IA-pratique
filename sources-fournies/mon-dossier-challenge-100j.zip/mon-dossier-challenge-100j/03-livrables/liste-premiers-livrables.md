﻿# Liste de mes premiers livrables

Nom :
Prénom :
Email-ID :

## Livrable 1

Nom du livrable :
Pourquoi il est utile :
Où je vais le classer :

## Livrable 2

Nom du livrable :
Pourquoi il est utile :
Où je vais le classer :

## Livrable 3

Nom du livrable :
Pourquoi il est utile :
Où je vais le classer :

## Rappel

Le livrable prouve.