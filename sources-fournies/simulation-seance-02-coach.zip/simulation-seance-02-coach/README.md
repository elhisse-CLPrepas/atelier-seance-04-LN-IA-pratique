﻿# Simulation de la séance 02 — Madame Nadia, coach

LN-IA · Module 01 · 28 septembre 2026

Tout le cas est fictif : identité, activité, session de formation et évaluations. Ce dossier sert à apprendre à travailler dans VS Code avec Codex. Il ne correspond pas à une offre commerciale réelle.

## Commencer en cinq gestes

1. Extraire le ZIP dans un dossier normal.
2. Ouvrir ce dossier dans VS Code avec « Fichier > Ouvrir le dossier ».
3. Ouvrir `DEMARRER-ICI.html` dans votre navigateur. Il donne accès aux prompts et aux exemples.
4. Dans VS Code, ouvrir votre espace Codex connecté. Copier un prompt depuis le support HTML ou depuis `02-prompts/` et le coller dans Codex. Un prompt se colle dans Codex, pas dans le terminal.
5. Lire le résultat, choisir une correction, enregistrer puis rouvrir le fichier. Compléter ensuite la preuve avec ce que vous avez réellement vérifié.

Lire le support HTML ne déclenche aucune IA. Codex doit être disponible dans votre VS Code pour exécuter les consignes. Les fichiers Markdown s’ouvrent dans l’éditeur et dans son aperçu Markdown. Les pages HTML s’ouvrent dans un navigateur.

## Le cas commun aux trois productions

Madame Nadia est une coach fictive en organisation pour indépendants à Marrakech. Elle débute dans VS Code. Son projet s’appelle « Cap sur ma semaine ». Il aide un indépendant à choisir trois priorités, construire un planning réaliste et décider d’une première action.

L’offre simulée est un atelier en ligne de 90 minutes pour six personnes. Ce format de 90 minutes appartient au cas de coaching. La séance LN-IA durant laquelle vous travaillez sur ce cas dure 100 minutes.

Trois livrables sont liés à ce même besoin :

| Livrable | Fonction | Fichier à produire avec Codex |
| --- | --- | --- |
| Guide | Aider le participant à préparer sa semaine | `03-livrables/guide/guide-cap-sur-ma-semaine.md` |
| Landing page | Expliquer l’atelier et son programme | `03-livrables/landing-page/index.html` et `style.css` |
| Rapport | Lire les données de la session fictive et proposer des améliorations | `03-livrables/rapport/rapport-formation-cap-sur-ma-semaine.md` |

Le guide et le rapport sont en Markdown pour faciliter la pratique dans VS Code. La page web fonctionne sans installation de dépendances.

## Un parcours simple pour la séance 02

| Temps indicatif | Geste à faire | Support |
| --- | --- | --- |
| 0–10 min | Lire l’identité, le besoin et les trois livrables | `01-depart/fiche-depart-candidat.md` |
| 10–25 min | Retrouver les fichiers puis expliquer le cas | `01-depart/objectif-personnel-challenge.md` |
| 25–50 min | Lancer le prompt 01, relire l’objectif et vérifier le classement avec le prompt 02 | `02-prompts/01-clarifier-mon-intention.md` |
| 50–70 min | Lancer le prompt 03 et corriger un passage du guide | `02-prompts/03-produire-le-guide.md` |
| 70–90 min | Enregistrer, fermer, rouvrir et examiner le guide | Prompts 06 puis 07 |
| 90–100 min | Présenter une preuve et choisir la prochaine action | `04-portfolio-preuves/preuves-semaine-01.md` |

Les prompts 04 et 05 permettent de poursuivre avec la page web et le rapport après la séance, ou pendant une démonstration du formateur. Il n’est pas nécessaire de terminer trois productions pendant les 100 minutes.

Pour une démonstration complète en une demande, utiliser le prompt 00. Il produit les trois livrables et un contrôle technique. Il laisse la relecture humaine à renseigner.

## Les quatre dossiers de travail

| Dossier | Contenu |
| --- | --- |
| `01-depart` | Identité fictive, objectif rempli, brief du projet, JSON et CSV |
| `02-prompts` | Prompt maître, prompts guidés et journal de prompts |
| `03-livrables` | Liste remplie des trois productions et dossiers de sortie |
| `04-portfolio-preuves` | Preuve de travail et bilan humain à compléter après exécution |

`exemples-reference/` contient trois exemples déjà rédigés. Comparez-les à votre résultat après votre propre essai. Ils ne sont pas vos preuves d’exécution. Les dossiers de production contiennent seulement leurs consignes au départ.

`references/support-seance-01-original.html` conserve le support fourni. `references/correspondance-seance-01-seance-02.md` explique le passage de ses sept dossiers aux quatre dossiers de cette simulation.

## Ouvrir les pages et contrôler les données

Double-cliquer sur `DEMARRER-ICI.html` ou sur un `index.html` de landing page. Aucune publication n’est nécessaire.

Si Python est déjà disponible, le terminal permet un serveur local facultatif :

```bash
python -m http.server 8000 --bind 127.0.0.1
```

Ouvrir ensuite `http://127.0.0.1:8000/DEMARRER-ICI.html`. Garder le terminal ouvert. Arrêter le serveur avec Ctrl+C. Sous Windows, utiliser `py` à la place de `python` si c’est la commande installée.

Pour recalculer les indicateurs de la session fictive :

```bash
python outils/calculer-indicateurs.py
```

L’outil lit le CSV, vérifie les six lignes puis affiche les calculs. Il ne modifie aucun fichier. Codex peut utiliser cet outil si Python est présent ou effectuer un calcul équivalent.

## Ce que vous devez décider vous-même

Choisissez une formulation à améliorer, expliquez votre correction et décrivez un contrôle concret. Exemple : « J’ai ajouté un créneau libre le mercredi pour absorber un imprévu. J’ai vérifié que les trois priorités restent planifiées. » Cet exemple n’est pas une action déjà accomplie.

L’IA propose. L’humain contrôle. L’atelier organise. Le livrable prouve.
