﻿# Critères de réussite de l’exercice

Pour valider une première pratique de la séance 02 :

- Je retrouve la fiche, l’objectif et la liste de livrables.
- Je peux expliquer le besoin du coach et le lien entre les trois productions.
- J’ai envoyé au moins un prompt dans Codex et retrouvé le fichier obtenu.
- J’ai choisi une correction et je sais expliquer pourquoi.
- J’ai enregistré puis rouvert le fichier pour vérifier le résultat.
- Ma preuve décrit cette action avec le chemin exact du fichier.

Pour poursuivre après la séance : ouvrir la landing page et tester son bouton, puis recalculer au moins un indicateur du rapport. La présence de trois exemples déjà rédigés ne suffit pas à valider ma propre pratique.
