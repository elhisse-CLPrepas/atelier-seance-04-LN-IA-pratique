﻿# Preuve de progression — séance 02

Cas travaillé : Madame Nadia, coach fictive. Projet : Cap sur ma semaine.
Statut initial : atelier préparé, exécution par le candidat à réaliser.

## Intention

Produire un premier guide en Markdown et apprendre à expliquer une correction. Poursuivre ensuite avec la page web et le rapport.

## Livrable à montrer

Chemin prévu : `03-livrables/guide/guide-cap-sur-ma-semaine.md`.
Autres chemins prévus : `03-livrables/landing-page/index.html` et `03-livrables/rapport/rapport-formation-cap-sur-ma-semaine.md`.

## Trace réelle à compléter après votre travail

Date et heure de mon essai : à renseigner.
Prompt réellement utilisé : à renseigner.
Fichier créé ou modifié : à renseigner.
Phrase ou partie avant correction : à renseigner.
Ma décision de correction : à renseigner.
Partie après correction : à renseigner.
Contrôle réellement effectué : à renseigner.
Résultat observé après fermeture et réouverture : à renseigner.
Capture éventuelle et nom du fichier : à renseigner si une capture a été réalisée.

## Ma prochaine action

Action choisie : à renseigner après l’essai.
Date cible : à renseigner.

Les faits du cas sont fictifs. Votre geste dans VS Code et votre preuve doivent correspondre à une action réellement faite pendant l’exercice.
