﻿Travaille dans le dossier ouvert dans VS Code. Lis AGENTS.md, 01-depart/brief-projet-coach.md et 01-depart/donnees/cas-coach.json. Il s’agit de la simulation de Madame Nadia, coach en organisation pour indépendants. Le projet commun est « Cap sur ma semaine ». Conserve la mention « Simulation pédagogique — données fictives ». Écris directement dans les fichiers indiqués. Ne publie rien.

Lis 04-portfolio-preuves/preuves-semaine-01.md et le contrôle technique s’il existe. Examine les fichiers réellement créés pendant cette exécution.

Ajoute dans 04-portfolio-preuves/trace-codex.md une trace factuelle : date d’exécution si connue, prompts utilisés dans cette conversation, chemins produits, contrôles réalisés, résultats observés et étapes restantes. N’invente ni heure, ni commande, ni capture.

Ne remplis pas la correction personnelle, la relecture, la décision ou la signature du candidat à sa place. Donne-moi les quatre gestes suivants : ouvrir le fichier du guide, modifier une phrase en expliquant pourquoi, enregistrer et rouvrir le fichier, puis compléter moi-même preuves-semaine-01.md.

Si seuls les exemples-reference existent, indique qu’aucune production du candidat n’a encore été constatée.
