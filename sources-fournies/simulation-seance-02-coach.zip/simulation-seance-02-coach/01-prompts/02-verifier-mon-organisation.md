﻿Travaille dans le dossier ouvert dans VS Code. Lis AGENTS.md, 01-depart/brief-projet-coach.md et 01-depart/donnees/cas-coach.json. Il s’agit de la simulation de Madame Nadia, coach en organisation pour indépendants. Le projet commun est « Cap sur ma semaine ». Conserve la mention « Simulation pédagogique — données fictives ». Écris directement dans les fichiers indiqués. Ne publie rien.

Lis README.md et 03-livrables/liste-premiers-livrables.md. Vérifie que les dossiers 01-depart, 02-prompts, 03-livrables et 04-portfolio-preuves existent et que les trois sorties prévues sont clairement identifiées.

Crée 01-depart/repere-mon-dossier.md, une fiche de repérage de quinze lignes maximum. Indique : le rôle du dossier, mon objectif, où lire les données, où écrire chaque production et où garder ma preuve. Termine par « L’IA propose. L’humain contrôle. L’atelier organise. Le livrable prouve. »

Ne remplace pas le README principal. Ne déclare aucun livrable achevé avant de l’avoir trouvé et lu. Indique un fichier que je dois ouvrir moi-même pour vérifier son emplacement.
