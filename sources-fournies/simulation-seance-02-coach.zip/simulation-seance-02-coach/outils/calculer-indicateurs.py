#!/usr/bin/env python3
"""Recalculer les indicateurs fictifs sans modifier les fichiers du pack."""
import csv
import json
from pathlib import Path
from statistics import mean

root = Path(__file__).resolve().parents[1]
case = json.loads((root / '01-depart/donnees/cas-coach.json').read_text(encoding='utf-8'))
with (root / '01-depart/donnees/evaluations-session-simulee.csv').open(encoding='utf-8', newline='') as source:
    rows = list(csv.DictReader(source))
try:
    if len(rows) != case['session_fictive']['presents']:
        raise ValueError('Le nombre de lignes ne correspond pas au scénario.')
    if len({r['participant_id'] for r in rows}) != len(rows):
        raise ValueError('Un identifiant de participant apparaît plusieurs fois.')
    if sum(s['minutes'] for s in case['projet']['programme']) != 90:
        raise ValueError('Le programme ne totalise pas 90 minutes.')
    before = [int(r['score_avant_sur_5']) for r in rows]
    after = [int(r['score_apres_sur_5']) for r in rows]
    satisfaction = [int(r['satisfaction_sur_5']) for r in rows]
    if not all(1 <= n <= 5 for n in before + after + satisfaction):
        raise ValueError('Un score sort de l’échelle de 1 à 5.')
    if not all(r['plan_complet'] in ('oui', 'non') for r in rows):
        raise ValueError('plan_complet doit valoir oui ou non.')
except (KeyError, ValueError) as error:
    raise SystemExit(f'Données à corriger : {error}')

complete = sum(r['plan_complet'] == 'oui' for r in rows)
def number(value, decimals=2):
    return f'{value:.{decimals}f}'.replace('.', ',')

print('SIMULATION PÉDAGOGIQUE — toutes les données sont fictives')
print(f'Projet : {case["projet"]["titre"]}')
print(f'Nombre de réponses : {len(rows)}')
print(f'Sommes avant / après / satisfaction : {sum(before)} / {sum(after)} / {sum(satisfaction)}')
print(f'Moyenne avant : {number(mean(before))} / 5')
print(f'Moyenne après : {number(mean(after))} / 5')
print(f'Gain moyen : +{number(mean(b-a for a,b in zip(before,after)))} point')
print(f'Satisfaction : {number(mean(satisfaction))} / 5')
print(f'Plans complets : {complete} / {len(rows)} = {number(100*complete/len(rows),1)} %')
print('Ces résultats ne décrivent aucune formation réelle.')
