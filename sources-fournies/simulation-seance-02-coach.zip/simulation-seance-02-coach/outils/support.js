document.querySelectorAll('[data-copy]').forEach((button) => {
  button.addEventListener('click', async () => {
    const source = document.getElementById(button.dataset.copy);
    const text = source.textContent;
    const status = document.getElementById('copy-status');
    let copied = false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        copied = true;
      }
    } catch { copied = false; }
    if (!copied) {
      const area = document.createElement('textarea');
      area.value = text;
      area.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.append(area);
      area.select();
      try { copied = document.execCommand('copy'); } catch { copied = false; }
      area.remove();
      button.focus();
    }
    if (copied) {
      const old = button.textContent;
      button.textContent = 'Copié dans le presse-papiers';
      status.textContent = 'Prompt copié. Revenez dans Codex pour le coller et l’exécuter.';
      setTimeout(() => { button.textContent = old; }, 2200);
    } else {
      source.closest('details').open = true;
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(source);
      selection.removeAllRanges(); selection.addRange(range);
      source.focus();
      status.textContent = 'Le texte est sélectionné. Utilisez Ctrl+C ou Commande+C, ou téléchargez le fichier .md.';
    }
  });
});
