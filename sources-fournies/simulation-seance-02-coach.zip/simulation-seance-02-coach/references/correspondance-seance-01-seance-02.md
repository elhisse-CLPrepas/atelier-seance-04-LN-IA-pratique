﻿# Du support fourni à la simulation de la séance 02

Source : `support-seance-01-prompts-textes-a-copier (1).html`, joint par le formateur. Copie inchangée conservée sous `support-seance-01-original.html`.

Les rubriques des trois fichiers de cadrage ont été remplies avec le cas fictif de Madame Nadia. Les prompts « Clarifier mon intention », « Transformer une idée vague en objectif » et « Créer mon premier README » ont été réunis et adaptés dans les prompts 01 et 02.

Le support de séance 01 propose sept dossiers. Ce pack utilise les quatre dossiers de la séance 02 pour simplifier la démonstration.

| Support de séance 01 | Simulation de séance 02 |
| --- | --- |
| 00-cadrage/fiche-depart-candidat.md | 01-depart/fiche-depart-candidat.md |
| 00-cadrage/objectif-personnel-challenge.md | 01-depart/objectif-personnel-challenge.md |
| 00-cadrage/liste-premiers-livrables.md | 03-livrables/liste-premiers-livrables.md |
| 01-prompts | 02-prompts |
| 02-documents | 03-livrables/guide et 03-livrables/rapport |
| 03-supports-visuels | Aucun visuel supplémentaire requis pour ce cas |
| 04-page-web | 03-livrables/landing-page |
| 05-workflows | Instructions dans AGENTS.md et 02-prompts |
| 06-portfolio-preuves | 04-portfolio-preuves |

Le scénario, les évaluations et les exemples sont des créations pédagogiques pour cette simulation. Aucune donnée du CSV ne provient d’un participant réel.
