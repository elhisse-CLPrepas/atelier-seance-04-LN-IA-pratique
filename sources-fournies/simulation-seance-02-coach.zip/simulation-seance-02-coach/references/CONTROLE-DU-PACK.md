﻿# Contrôle du pack livré

Version du 28 septembre 2026.

- Le support HTML original est conservé sans modification.
- Les fichiers de cadrage sont remplis avec le même cas fictif : Madame Nadia, coach en organisation, projet « Cap sur ma semaine ».
- Les trois exemples partagent le même public et le programme de 90 minutes.
- Les six évaluations du CSV donnent les indicateurs du rapport : 2,00 avant, 3,67 après, gain +1,67 point, satisfaction 4,33, plans complets 5/6 soit 83,3 %.
- Les huit boutons de copie transmettent exactement les textes des huit fichiers de prompts.
- Les liens du support et le téléchargement d’un prompt ont été testés.
- Le bouton de la landing page atteint la section programme.
- Le support et la landing page ont été ouverts dans un navigateur à 1366 pixels et à 390 pixels de largeur. Aucun débordement horizontal n’a été constaté.
- L’ouverture directe des fichiers HTML a été testée. Les exemples ne nécessitent pas d’installation.

Ce contrôle porte sur les ressources du pack et ses exemples. L’exécution des prompts dans le VS Code du candidat reste l’activité à réaliser. Les preuves de cette pratique ne sont pas préremplies.
