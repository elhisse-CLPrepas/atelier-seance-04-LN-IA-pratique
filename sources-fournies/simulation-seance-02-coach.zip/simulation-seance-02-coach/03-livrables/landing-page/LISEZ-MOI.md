﻿# Dossier de production — landing-page

Codex créera ici : index.html et style.css.

Au départ, aucune production du candidat n’est déclarée réalisée. Le cadrage est rempli et les prompts sont prêts. Les exemples se trouvent dans `exemples-reference/` à la racine du pack.
