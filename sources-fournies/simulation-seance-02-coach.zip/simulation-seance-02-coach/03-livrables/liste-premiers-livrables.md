﻿# Liste de mes premiers livrables — cas rempli

Simulation pédagogique — Madame Nadia, coach en organisation.
Email-ID : nadia@example.invalid
Projet commun : Cap sur ma semaine

## Livrable 1

Nom : Guide pratique — Cap sur ma semaine.
Utilité : aider un indépendant à choisir trois priorités, estimer ses tâches et préparer un planning.
Classement : `03-livrables/guide/guide-cap-sur-ma-semaine.md`.
Entrées : fiche candidat, objectif, brief et cas-coach.json.
Format : Markdown, six sections, exercices et modèle de planning.
Premier contrôle : un lecteur peut compléter le planning avec trois priorités et une marge pour un imprévu.
Date cible simulée : 28 septembre 2026 pour une première version, à améliorer ensuite.
Prochaine action : lancer le prompt 03 après clarification.
État dans le pack initial : à produire avec Codex.

## Livrable 2

Nom : Landing page — Cap sur ma semaine.
Utilité : présenter le même atelier en ligne de 90 minutes pour six personnes.
Classement : `03-livrables/landing-page/index.html` et `style.css`.
Entrées : brief, JSON et guide s’il a été produit.
Format : une page HTML/CSS autonome et adaptée au téléphone.
Premier contrôle : le programme totalise 90 minutes et le bouton « Voir le programme » atteint la bonne section.
Date cible simulée : 30 septembre 2026.
Prochaine action : lancer le prompt 04 puis ouvrir la page dans le navigateur.
État dans le pack initial : à produire avec Codex.

## Livrable 3

Nom : Rapport de formation — Cap sur ma semaine.
Utilité : apprendre à décrire une session et proposer des améliorations à partir de données.
Classement : `03-livrables/rapport/rapport-formation-cap-sur-ma-semaine.md`.
Entrées : brief, cas-coach.json, CSV et dictionnaire des données.
Format : Markdown, tableau des indicateurs et trois améliorations.
Premier contrôle : recalculer les moyennes et le taux de plans complets, puis retrouver chaque donnée dans la source.
Date cible simulée : 2 octobre 2026.
Prochaine action : lancer le prompt 05 puis vérifier les calculs.
État dans le pack initial : à produire avec Codex.

## Rappel

Le livrable prouve. Les exemples déjà présents dans `exemples-reference/` servent à comparer les résultats. Ils ne remplacent pas vos fichiers de production ni votre contrôle.
