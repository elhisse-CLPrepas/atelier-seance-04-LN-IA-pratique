﻿# Dossier de production — rapport

Codex créera ici : rapport-formation-cap-sur-ma-semaine.md.

Au départ, aucune production du candidat n’est déclarée réalisée. Le cadrage est rempli et les prompts sont prêts. Les exemples se trouvent dans `exemples-reference/` à la racine du pack.
