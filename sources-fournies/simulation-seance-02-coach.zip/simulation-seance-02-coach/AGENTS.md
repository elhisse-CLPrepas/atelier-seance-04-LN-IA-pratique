﻿# Instructions pour Codex — Simulation LN-IA

Ce dossier contient un cas pédagogique fictif. Les données sont inventées et autorisées pour la simulation. Aucune personne réelle n’est à contacter.

## Sources à lire

Lire README.md, 01-depart/fiche-depart-candidat.md, 01-depart/objectif-personnel-challenge.md, 01-depart/brief-projet-coach.md, 01-depart/donnees/cas-coach.json et 03-livrables/liste-premiers-livrables.md. Pour le rapport, lire également le CSV et son dictionnaire de données.

Le JSON définit les faits du cas. Le CSV définit les évaluations fictives. Garder la même identité, le même titre, le même public et le même programme dans les trois productions. La session du coach dure 90 minutes. La séance LN-IA dure 100 minutes.

## Travail attendu

- Suivre le prompt choisi dans 02-prompts/. Écrire dans les chemins de sortie indiqués.
- Préserver le cadrage rempli et les sources. Une proposition de reformulation va dans un nouveau fichier objectif-personnel-reformule.md.
- Si un livrable existe, le lire et l’améliorer sans effacer le travail personnel. Garder la version antérieure sous un nom daté si le changement est important.
- Produire du Markdown, du HTML et du CSS simples. Ne pas ajouter de framework, de dépendance ou de compte requis.
- Rendre la mention « Simulation pédagogique — données fictives » visible dans chaque livrable et dans la landing page.
- Ne pas inventer prix, certificat, client réel, témoignage réel, contact opérationnel ou résultat garanti. Le CTA est une ancre « Voir le programme ».
- Ne pas publier, créer de dépôt, envoyer de message, ajouter d’outil de suivi ou brancher un formulaire externe. Cette mission concerne les fichiers locaux.
- Recalculer les indicateurs du CSV. Arrondir seulement à l’affichage : moyennes à deux décimales, pourcentage à une décimale.
- Décrire uniquement les commandes et les vérifications réellement exécutées. Une lecture de code n’est pas un test dans le navigateur.
- Ne jamais déclarer une relecture humaine, une signature ou une formation réelle accomplie par déduction.
- Les exemples-reference sont consultables sur demande ou pour comparaison après production. Ne pas les recopier comme preuve d’une exécution nouvelle.

## Fin d’une étape

Indiquer le fichier créé ou modifié, son emplacement, le contrôle réellement fait et une action courte que le candidat doit effectuer. La personne complète elle-même la décision et la validation humaine dans son portfolio.
