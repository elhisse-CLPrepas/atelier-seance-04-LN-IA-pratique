﻿# Modèle de phrase d’engagement personnel

**Challenge 100 Jours — Relance Automne 2026**  
**Atelier LN-IA — Module 01 : cadrage et prise de conscience**  
**Séance 04 : lundi 05 octobre 2026 — Horaire à confirmer**  
**Thème : produire, contrôler et s’engager**  
**Version : V3 — Mise à jour : 04 octobre 2026**  
**Statut du modèle : VALIDÉ POUR DIFFUSION**

Ce modèle vous aide à choisir un engagement personnel concret : un livrable utile, un rythme réaliste, un contrôle humain et des preuves retrouvables. Il constitue l’une des quatre pièces de remise de la séance 04, avec le prompt réellement utilisé, le livrable corrigé et la preuve datée du contrôle.

La validation de ce modèle ne valide pas votre engagement individuel. Complétez-le avec vos propres choix, relisez-le puis présentez-le au formateur. Aucun résultat, disponibilité, signature ou contrôle réalisé ne doit être inventé.

## 1. Comment utiliser le modèle

1. Reprenez votre objectif et un usage de votre carte personnelle des usages IA.
2. Choisissez un premier livrable limité et un public précis.
3. Décidez d’un rythme que vous pouvez tenir et d’une échéance ; un point non décidé reste « à confirmer ».
4. Précisez un contrôle observable et les fichiers que vous conserverez.
5. Rédigez les quatre rubriques ci-dessous, puis relisez votre engagement.

Enregistrez votre copie personnelle sous le nom `phrase-engagement-personnel.md`, avec un pseudonyme ou un identifiant dans les pièces partageables. Conservez les coordonnées, la fiche nominative et toute signature dans votre espace privé.

## 2. Une phrase courte à personnaliser

> Pendant le Challenge 100 Jours, je choisis de produire [livrable] pour [public], afin de [besoin]. Je réserve [fréquence et durée réalistes] et vise [échéance choisie ou à confirmer]. Je vérifie [critère observable], j’explique les corrections retenues et je conserve [fichiers et preuve]. Je garde la responsabilité de mes décisions et du partage.

Cette phrase doit refléter vos choix. Elle ne constitue pas une promesse de résultat garanti ni une déclaration de contrôles déjà accomplis.

## 3. Mon engagement à compléter

Copiez ce bloc dans votre fichier personnel :

```markdown
# Phrase d’engagement personnel

Challenge 100 Jours — Relance Automne 2026
Module 01 — Séance 04 du lundi 05 octobre 2026
Pseudonyme ou identifiant : [à compléter]
Date réelle de rédaction ou de mise à jour : [à renseigner après action]
Statut personnel : brouillon / relu par moi / prêt pour relecture du formateur

## Mon engagement

Mon objectif : [objectif concret].
Le public de ma production : [public].
Le besoin auquel je souhaite répondre : [besoin].
L’usage IA choisi dans ma carte : [usage].
Mon premier livrable et son nom de fichier : [livrable et fichier].
Mon critère de réussite : [résultat observable].
Mon échéance choisie : [date ou à confirmer].

## Ma responsabilité

J’utilise uniquement les informations confirmées et autorisées : [entrées].
Je signale les informations manquantes : [manques ou à confirmer].
Avant de retenir la production, je vérifie : [contrôle précis].
Je conserve la raison des corrections et je décide de la version retenue.
Je sélectionne uniquement un extrait autorisé pour la relecture ou le partage.
Je garde la responsabilité de mes décisions et de la diffusion.

## Mes preuves

Je prévois de conserver :
- le prompt réellement envoyé : [fichier ou section] ;
- le brouillon obtenu : [fichier] ;
- le livrable corrigé : [fichier] ;
- le journal de correction : [fichier ou section] ;
- la trace de réouverture et du contrôle : [emplacement dans preuves-module-01.md].

Je renseignerai la date réelle et mes observations après avoir effectué le contrôle.
Les pièces encore manquantes sont : [à compléter].
La fiche d’identification reste dans mon espace privé et sera remise séparément.

## Ma régularité

Le rythme que je choisis : [fréquence et durée réalistes].
Ma prochaine action : [action limitée].
Le créneau ou l’échéance prévue : [choix ou à confirmer].
Si je rencontre une difficulté, je prévois de : [adapter le périmètre, demander
une aide précise ou revoir mon planning].
Je documenterai les changements de mon engagement plutôt que de déclarer
un travail que je n’ai pas réalisé.
```

## 4. Critères de relecture

Cochez une case après avoir vérifié votre texte, sans déclarer la réalisation du travail à venir :

- [ ] L’engagement est écrit à la première personne et reflète mes choix.
- [ ] Mon objectif, mon public et le besoin sont précis.
- [ ] J’ai nommé un premier livrable et son fichier.
- [ ] Un critère observable permet de contrôler le résultat.
- [ ] Mon échéance est choisie ou explicitement laissée à confirmer.
- [ ] Mon rythme correspond à mes disponibilités réelles.
- [ ] Le contrôle humain prévu est explicite.
- [ ] Les preuves prévues sont nommées et classables.
- [ ] Je distingue les actions prévues des contrôles réellement effectués.
- [ ] Les informations privées sont séparées des pièces partageables.
- [ ] Les quatre rubriques sont présentes : engagement, responsabilité, preuves et régularité.

Points à revoir dans mon engagement : **[à compléter]**  
Prochaine action : **[à compléter]**

## 5. Place dans le dossier de séance 04

Les quatre pièces attendues sont :

| Pièce | Ce qu’elle doit montrer |
| --- | --- |
| Prompt réellement utilisé | La consigne effectivement envoyée pour le premier essai. |
| Livrable corrigé | Une version qui répond au besoin, après contrôle et correction. |
| Preuve datée | Le fichier effectivement rouvert, la date réelle, le contrôle et le point restant à confirmer. |
| Engagement personnel | Le livrable choisi, le rythme réaliste, la responsabilité et les preuves prévues. |

Utilisez la [checklist des preuves du module 01](checklist-preuves-module-01.md) pour préparer la remise. Le brouillon et le journal restent accessibles pour expliquer la correction. Le formateur examine les pièces réelles avant de décider du statut pédagogique.

Le site de l’atelier aide à consigner et exporter les saisies. Il n’exécute pas les prompts et ne valide pas automatiquement l’engagement. Un export ou une case cochée ne vaut pas validation du module.

## 6. Références et validation du modèle

- [Index des supports validé pour diffusion](INDEX-supports-seance-04.md).
- [Liaison entre les séances 03 et 04](liaison-fin-seance-03-vers-seance-04.md).
- [Site de l’atelier et ressources](https://elhisse-clprepas.github.io/Atelier-seance-04-05-0ctobre-2026/).

**Décision sur le présent modèle V3 : VALIDÉ POUR DIFFUSION — 04 octobre 2026.**

Validation enregistrée conformément à l’instruction du formateur dans cette conversation, après contrôle de la cohérence avec l’index : date, quatre pièces de remise, responsabilité humaine, confidentialité et preuves. Les liens locaux ont été vérifiés. Cette décision porte sur le modèle, et non sur les engagements individuels ou les réalisations des candidats.
