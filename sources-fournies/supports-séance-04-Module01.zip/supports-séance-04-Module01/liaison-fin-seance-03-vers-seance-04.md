﻿# Liaison entre la séance 03 et la séance 04

**Challenge 100 Jours — Relance Automne 2026**  
**Atelier LN-IA — Module 01 : cadrage et prise de conscience**  
**Séance 03 : vendredi 02 octobre 2026**  
**Séance 04 : lundi 05 octobre 2026 — Horaire à confirmer**  
**Durée proposée de la séance 04 : 100 minutes**  
**Version : V3 — Mise à jour : 04 octobre 2026**  
**Statut : VALIDÉ POUR DIFFUSION**

Cette liaison aide le candidat à passer de sa carte des usages IA à un premier essai concret. Elle prépare la production, le contrôle, l’engagement personnel et le classement des preuves de la séance 04.

## 1. Message de clôture de la séance 03

Lors de la séance 03, vous avez travaillé sur trois usages de l’IA liés à votre objectif. Pour chaque usage, vous avez prévu un livrable, identifié un risque et choisi un contrôle humain. Si votre carte est encore incomplète, signalez les points à reprendre.

L’IA peut vous aider à produire ; vous gardez la responsabilité du besoin, des informations transmises, des corrections et du partage.

Pour la séance 04, choisissez un seul usage et un livrable limité : une fiche courte, un texte de présentation ou une trame sans données personnelles réelles. Vous préparerez une première version, la relirez, expliquerez une correction et conserverez une preuve datée de votre contrôle.

Votre engagement précisera ce que vous choisissez de produire, le rythme que vous pouvez tenir et les vérifications dont vous prenez la responsabilité.

## 2. À préparer avant le lundi 05 octobre

Cochez uniquement ce que vous avez réellement préparé :

- [ ] Mon objectif personnel et le public de ma production sont relus.
- [ ] Ma carte comporte trois usages IA, leurs livrables, leurs risques et leurs contrôles ; sinon, les manques sont signalés.
- [ ] J’ai choisi un premier essai réalisable pendant l’atelier et nommé le fichier attendu.
- [ ] J’ai réuni les informations confirmées et autorisées, sans données de tiers inutiles.
- [ ] J’ai identifié les informations qui restent à confirmer.
- [ ] J’ai préparé un brouillon d’engagement et un rythme de travail réaliste.
- [ ] Je dispose d’un dossier personnel pour enregistrer le prompt, le brouillon, la correction et les preuves.
- [ ] J’ai une question précise sur mon usage de l’IA ou sur un contrôle à effectuer.
- [ ] J’ai vérifié l’état de ma fiche d’identification dans mon espace privé, selon les consignes du formateur.

Si la fiche administrative existe déjà dans une version approuvée par le formateur, utilisez cette version. Ne partagez pas les coordonnées ou la signature avec le groupe et ne les placez pas sur le site public.

## 3. Mon cadrage de départ

À compléter avec vos propres informations ; un manque reste « à confirmer ».

| Point à préciser | Ma réponse |
| --- | --- |
| Mon objectif et le besoin concret | [à compléter] |
| Le public de ma production | [à compléter] |
| L’usage IA choisi | [à compléter] |
| Le premier livrable et son nom de fichier | [à compléter] |
| Les informations confirmées et autorisées | [à compléter] |
| Les informations à confirmer | [à compléter] |
| Mon critère de réussite observable | [à compléter] |
| Le contrôle humain prévu | [à compléter] |
| Mon échéance et mon rythme choisis | [à compléter ou à confirmer] |
| Ma question pour le formateur | [à compléter] |

Question de préparation : **Quel premier livrable vais-je produire, quelle affirmation ou contrainte vais-je contrôler, et quelle trace conserverai-je pour expliquer mon travail ?**

Amorce d’engagement : « Je choisis de produire [livrable] pour [public]. Je réserve [rythme réaliste], je vérifie [critère] et je conserve [preuve]. Mon échéance est [date choisie ou à confirmer]. »

## 4. Ce qui se passera pendant la séance 04

| Durée | Action | Trace attendue |
| --- | --- | --- |
| 10 min | Choisir l’essai | Objectif reformulé et premier fichier choisi. |
| 15 min | Formaliser l’engagement | Livrable, rythme, contrôle et preuve prévus. |
| 30 min | Produire une première version | 10 minutes de démonstration puis 20 minutes de production candidat. |
| 20 min | Contrôler et corriger | Passage initial, correction retenue et justification. |
| 15 min | Relire à deux | Extrait autorisé, retour reçu et décision. |
| 10 min | Classer et préparer la suite | Fichier rouvert et preuve datée renseignée. |

**Total : 100 minutes.** La présentation accompagne l’atelier. Le cas de démonstration **Madame Samira** est fictif et préparé ; il ne doit pas être présenté comme votre propre production ni comme une réponse obtenue en direct.

À la fin, préparez quatre pièces clairement identifiables :

1. Le prompt réellement utilisé.
2. Le livrable corrigé.
3. La preuve datée du fichier rouvert et du contrôle effectué.
4. L’engagement personnel relu.

Conservez également le brouillon et l’explication de la correction. Remettez la fiche d’identification séparément par le canal privé convenu. Le formateur examine les pièces avant de décider du statut pédagogique ; un export ou une case cochée ne valide pas le module.

## 5. Supports à retrouver

- [Index des supports validé pour diffusion](INDEX-supports-seance-04.md).
- [Checklist des preuves du module 01](checklist-preuves-module-01.md).
- [Modèle de phrase d’engagement personnel](modele-phrase-engagement-personnel.md), à personnaliser avec le livrable, le rythme et l’échéance.
- [Affiche des étapes du 05 octobre 2026](affiche-etapes-seance-04-v2-05-octobre-2026.png).
- [Site de l’atelier et ressources](https://elhisse-clprepas.github.io/Atelier-seance-04-05-0ctobre-2026/).

## 6. Message court prêt à partager

> Bonjour,
>
> Pour la séance 04 du module 01, lundi 05 octobre 2026, relisez votre objectif et votre carte des usages IA. Choisissez un premier livrable limité, préparez les informations autorisées et un brouillon d’engagement réaliste.
>
> Pendant l’atelier, nous produirons une première version, expliquerons une correction et classerons une preuve datée. Les quatre pièces attendues sont le prompt utilisé, le livrable corrigé, la preuve du contrôle et l’engagement personnel.
>
> La fiche d’identification reste privée et sera remise séparément selon les consignes du formateur. Horaire à confirmer.
>
> Atelier LN-IA — Prof. Abderrahman EL HISSE

Ce message est préparé pour copie ; aucun envoi n’est effectué par cette mise à jour.

## 7. Contrôle et validation du document

- Date, thème et déroulé alignés sur le cahier actuel de la séance 04.
- Liens locaux vérifiés vers des fichiers présents.
- Quatre pièces de remise précisées ; confidentialité et validation humaine explicites.
- Aucun horaire, résultat candidat, signature ou contrôle personnel déclaré par anticipation.

**Décision : VALIDÉ POUR DIFFUSION — 04 octobre 2026.**  
Validation du présent document V3 enregistrée conformément à l’instruction du formateur dans cette conversation. Elle ne vaut pas validation des preuves des candidats ni approbation automatique des autres supports référencés.
