﻿# Guide atelier formateur — Séance 04

**Challenge 100 Jours — Relance Automne 2026**
**LN-IA — Module 01 : cadrage et prise de conscience**
**Lundi 05 octobre 2026 — Horaire à confirmer**
**Produire, contrôler et s’engager — Durée proposée : 100 minutes**
**Version V3 — Mise à jour : 04 octobre 2026**
**Pilotage : Prof. Abderrahman EL HISSE**
**Statut : contenu harmonisé — prêt pour relecture du formateur**

La séance clôture le module 01 par un premier essai limité, une correction expliquée, un engagement réaliste et des preuves retrouvables. L’engagement accompagne la production ; il ne remplace pas le livrable et son contrôle.

## 1. Objectifs observables

Le candidat doit pouvoir préciser son besoin et son public, choisir un usage de sa carte IA, conserver le prompt réellement envoyé, comparer le brouillon aux entrées et expliquer une correction ou une amélioration. Il choisit son rythme, enregistre puis rouvre le résultat, et distingue privé et partageable.

Les quatre pièces de remise sont : **prompt réellement utilisé, livrable corrigé, preuve datée du contrôle et engagement personnel**.

 Le brouillon et le journal de correction restent accessibles pour expliquer le travail.

## 2. Préparation du formateur

- [ ] Ouvrir le site, la présentation et la démonstration.
- [ ] Vérifier l’accès aux supports, à l’assistant choisi et aux téléchargements.
- [ ] Préparer un dossier de travail et le cas fictif Madame Samira.
- [ ] Prévoir une solution sans accès à une IA : analyser et corriger le brouillon préparé.
- [ ] Préparer les binômes et une question de relecture précise.
- [ ] Confirmer le canal privé de remise de la fiche nominative.
- [ ] Rappeler que les disponibilités et engagements sont choisis par le candidat.

Utiliser la fiche administrative déjà approuvée si elle existe. Ne pas créer une nouvelle obligation de signature ni collecter des coordonnées dans les pièces publiques. Les supports nécessaires sont liés en section 9.

## 3. Ouverture proposée

> Vous avez un objectif et une carte des usages IA. Aujourd’hui, choisissez > un usage pour produire un premier livrable limité. Vous comparerez la > réponse aux informations de départ, expliquerez une correction et garderez > une preuve datée. Votre engagement portera sur une pratique que vous pouvez > tenir. L’IA propose ; vous vérifiez et décidez.

Si un prérequis manque, aider à rédiger une version courte et signaler les points à compléter. Ne pas présenter une préparation incomplète comme acquise.

## 4. Déroulé de 100 minutes

| Durée | Séquence | Conduite du formateur | Trace attendue |
| --- | --- | --- | --- |
| 10 min | Choisir l’essai | Faire préciser le besoin, le public, les entrées et un critère observable. | Objectif reformulé et premier fichier. |
| 15 min | Formaliser l’engagement | Accompagner les quatre rubriques du modèle V3 et un rythme réaliste. | Livrable, échéance choisie ou à confirmer, contrôle et preuves prévus. |
| 30 min | Produire une première version | Démonstration de 10 minutes, puis production candidat de 20 minutes. | Prompt réellement envoyé et brouillon obtenu. |
| 20 min | Contrôler et corriger | Faire comparer aux entrées, conserver le passage initial et justifier le choix. | Journal et livrable corrigé. |
| 15 min | Relire à deux | Faire partager un extrait autorisé et une question précise. | Retour reçu et décision retenue. |
| 10 min | Classer et préparer la suite | Faire enregistrer, rouvrir et renseigner la date réelle. | Preuve datée et question pour le module 02. |

La présentation accompagne ces séquences et ne s’ajoute pas au minutage.
Les neuf prompts V3 sont des aides au choix, pas neuf exercices obligatoires.

## 5. Démonstration fictive Madame Samira

Dix minutes incluses dans la phase de production :

- **1 minute** : lire le besoin, le public et les seules entrées autorisées.
- **2 minutes** : expliquer le prompt et ses limites.
- **2 minutes** : faire repérer les ajouts injustifiés du brouillon préparé.
- **3 minutes** : comparer aux corrections et à la fiche corrigée.
- **2 minutes** : télécharger, rouvrir et montrer comment décrire un contrôle.

Le brouillon préparé comporte une certification, un résultat garanti, une durée et un tarif non fournis, ainsi qu’une demande inutile de données clients.
Faire expliquer pourquoi les retirer. Le scénario est fictif et préparé : ne pas le présenter comme une réponse produite en direct.

En cas d’essai réel, garder la réponse obtenue et analyser ses problèmes réels.
Ne pas inventer d’erreurs pour reproduire la démonstration. Sans accès à une IA, noter « exercice de contrôle sur brouillon préparé » ; cette variante ne fournit pas la preuve d’un prompt réellement exécuté par le candidat. L’essai reste à compléter.

## 6. Accompagner les exercices et les binômes

Les prompts 1, 4 et 5 accompagnent cadrage, production et correction. Les prompts 2 et 3 aident l’engagement. Les prompts 6 à 8 accompagnent les preuves, le partage prudent et le classement. Le prompt 9 prépare une question pour la suite.

Pour un débutant, limiter le périmètre à une fiche courte et une correction expliquée. Pour un candidat autonome, proposer un second format uniquement si le premier livrable et son contrôle sont terminés.

Exiger une comparaison aux entrées, pas seulement une demande à l’IA de se confirmer elle-même. Si aucune erreur factuelle n’est repérée, documenter une amélioration de clarté. Le binôme reçoit seulement un extrait autorisé, sans identité, coordonnées, signature ou données privées de tiers. Conserver le retour réellement reçu et le choix du candidat ; sinon, noter « à organiser ».

## 7. Observer les preuves et décider

| Critère | Pièce ou observation | Appréciation après relecture |
| --- | --- | --- |
| Besoin et public précis | Cadrage et objectif. | [satisfaisant / à compléter / à revoir] |
| Usage IA et contrôle humains | Carte des usages, prompt et entrées. | [satisfaisant / à compléter / à revoir] |
| Production cohérente | Livrable corrigé comparé au cadrage. | [satisfaisant / à compléter / à revoir] |
| Correction expliquée | Passage initial, problème, correction et raison. | [satisfaisant / à compléter / à revoir] |
| Engagement réaliste | Livrable, rythme, échéance choisie ou à confirmer et responsabilité. | [satisfaisant / à compléter / à revoir] |
| Confidentialité | Extrait autorisé et séparation des pièces privées. | [satisfaisant / à compléter / à revoir] |
| Preuve retrouvable | Fichier rouvert, date réelle et contrôle consigné. | [satisfaisant / à compléter / à revoir] |

Le candidat propose **à compléter**, **à relire** ou **prêt pour relecture**.
Après examen, le formateur consigne **validé**, **à compléter** ou **à revoir**,
avec le motif, la date réelle, la prochaine action et son responsable.

Un téléchargement, une case cochée ou une date d’export ne démontre pas une relecture. L’approbation d’un modèle ne valide pas les travaux individuels.
Utiliser la checklist V3 pour documenter la décision, sans cocher par anticipation.

## 8. Clôture et préparation du module 02

> Retrouvez vos quatre pièces. Montrez une correction et dites ce qui reste > à confirmer. Gardez le prompt utilisé, le résultat obtenu et une difficulté > précise : ils serviront à améliorer vos prochaines demandes.

Demander une prochaine action limitée et une question au formateur. Ne pas annoncer de date, horaire ou programme détaillé non confirmé du module 02. La fiche nominative est remise séparément selon le canal privé convenu.

## 9. Supports de conduite

- [Index validé](INDEX-supports-seance-04.md).
- [README validé](README-supports-seance-04.md).
- [Liaison validée](liaison-fin-seance-03-vers-seance-04.md).
- [Modèle d’engagement validé](modele-phrase-engagement-personnel.md).
- [Checklist des preuves V3](checklist-preuves-module-01.md).
- [Document candidats V3](seance-04-document-candidats.md).
- [Prompts Markdown V3](support-seance-04-prompts-exercices-a-copier.md).
- [Prompts HTML V3](support-seance-04-prompts-exercices-a-copier.html).
- [Prompts PDF V3](support-seance-04-prompts-exercices-a-copier.pdf).
- [Site de l’atelier](https://elhisse-clprepas.github.io/Atelier-seance-04-05-0ctobre-2026/).

## 10. État documentaire du guide

V3 harmonisée le 04 octobre 2026 : 100 minutes, quatre pièces, neuf prompts, confidentialité et décision humaine. Liens locaux contrôlés. Le guide est prêt pour la relecture du formateur ; aucune validation des candidats n’est attribuée.

Approbation du présent guide : **[à renseigner par le formateur]**.
Date et réserves éventuelles : **[à renseigner après relecture]**.
