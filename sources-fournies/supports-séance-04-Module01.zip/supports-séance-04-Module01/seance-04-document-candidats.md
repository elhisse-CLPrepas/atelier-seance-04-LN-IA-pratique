﻿# Document candidats — Séance 04

**Challenge 100 Jours — Relance Automne 2026**  
**LN-IA — Module 01 : cadrage et prise de conscience**  
**Lundi 05 octobre 2026 — Horaire à confirmer**  
**Produire, contrôler et s’engager — Durée proposée : 100 minutes**  
**Version V3 — Mise à jour : 04 octobre 2026**  
**Statut : contenu harmonisé — à relire par le formateur**

Cette séance vous aide à transformer un usage de votre carte IA en première
production corrigée. Vous préparez un engagement réaliste, expliquez une
correction et conservez une trace datée. L’IA propose ; vous vérifiez et décidez.

## 1. Avant de commencer

- [ ] Je retrouve mon objectif, mon public et ma carte de trois usages IA.
- [ ] Je choisis un premier livrable limité et son nom de fichier.
- [ ] Je réunis les seules informations confirmées et autorisées.
- [ ] Je signale les manques et prépare un critère de contrôle observable.
- [ ] Je prépare un brouillon d’engagement et un dossier personnel.

Si un document manque, préparez une version courte et notez ce qui reste à
compléter. Utilisez un pseudonyme dans les pièces partageables. La fiche
administrative approuvée par le formateur reste privée ; aucune nouvelle
signature ou pièce nominative n’est demandée dans ce support.

## 2. Déroulé de 100 minutes

| Durée | Action | Trace attendue |
| --- | --- | --- |
| 10 min | Choisir l’essai | Objectif reformulé, public et premier fichier. |
| 15 min | Formaliser l’engagement | Livrable, rythme, échéance choisie ou à confirmer, contrôle et preuves. |
| 30 min | Produire une première version | 10 minutes de démonstration puis 20 minutes de production candidat. |
| 20 min | Contrôler et corriger | Passage initial, correction retenue et justification. |
| 15 min | Relire à deux | Extrait autorisé, retour reçu et décision. |
| 10 min | Classer et préparer la suite | Fichier rouvert et preuve datée renseignée. |

La présentation accompagne ces séquences. Le cas de démonstration Madame
Samira est fictif et préparé ; il ne prouve pas une production en direct.

## 3. Choisir et produire

Reprenez un usage de votre carte. Précisez le besoin, le public, le format,
les rubriques et les informations autorisées. Choisissez une production
réalisable dans le temps de l’atelier : fiche courte, présentation d’activité
ou trame sans données réelles de tiers.

Utilisez les prompts 1 et 4 du [support de prompts](support-seance-04-prompts-exercices-a-copier.md)
si vous avez besoin d’aide. Personnalisez les champs puis exécutez la consigne
dans votre assistant. Conservez le prompt effectivement envoyé et le brouillon
réellement obtenu. Le site ne produit pas de réponse IA.

## 4. Rédiger un engagement personnel

Complétez le [modèle V3 validé](modele-phrase-engagement-personnel.md) dans
`phrase-engagement-personnel.md`, avec quatre rubriques :

- **Mon engagement** : besoin, public, livrable et échéance choisie ou à confirmer.
- **Ma responsabilité** : entrées autorisées, contrôle prévu et décisions conservées.
- **Mes preuves** : prompt, brouillon, version corrigée, journal et trace datée.
- **Ma régularité** : fréquence, durée réalistes et prochaine action.

Les prompts 2 et 3 aident à rédiger et relire. L’outil ne choisit pas vos
disponibilités à votre place. Relisez le texte et approuvez vos propres choix.

## 5. Contrôler, corriger et faire relire

Comparez chaque affirmation du brouillon aux entrées. Repérez les ajouts
injustifiés, les contraintes oubliées et les données inutiles. Si aucun fait
erroné n’est repéré, expliquez une amélioration de clarté sans inventer d’erreur.

Dans `journal-production-correction.md`, conservez :

| Élément | Observation à renseigner |
| --- | --- |
| Passage avant correction | [extrait réel] |
| Problème ou amélioration | [ce que j’ai observé] |
| Vérification effectuée | [méthode et résultat réel] |
| Passage retenu | [extrait corrigé] |
| Motif du choix | [explication personnelle] |
| Point restant à confirmer | [point ou aucun point identifié après contrôle] |

Le prompt 5 propose des corrections ; vous les vérifiez. Partagez avec le
binôme un extrait déjà anonymisé et une question précise, puis notez le retour
réel et votre décision. Le prompt 7 aide à limiter l’extrait, sans recevoir
vos données privées d’origine. Si la relecture n’a pas eu lieu, notez « à organiser ».

## 6. Classer et rouvrir les fichiers

Enregistrez le livrable corrigé sous un nom qui le distingue du brouillon,
puis rouvrez-le. Notez le nom, l’emplacement, la date réelle et le contrôle
effectué dans `preuves-module-01.md`. Une capture reste facultative et ne
remplace pas le fichier et l’explication.

La [checklist V3](checklist-preuves-module-01.md) vous aide à réunir les preuves.
Les prompts 6 et 8 accompagnent le classement sans déclarer les fichiers
manquants présents et sans supprimer vos versions.

## 7. Quatre pièces à remettre

- [ ] Le prompt réellement utilisé est conservé et identifiable.
- [ ] Le livrable corrigé est enregistré et retrouvable.
- [ ] La preuve datée décrit le fichier rouvert et le contrôle réel.
- [ ] L’engagement personnel est relu et adapté à mes disponibilités.

Gardez le brouillon et le journal pour expliquer la correction. Un export
regroupé convient si les quatre pièces sont distinctes. La fiche nominative,
les coordonnées et la signature restent dans un espace privé, remises
séparément par le canal convenu avec le formateur.

## 8. Statut et suite

Choisissez un statut provisoire : **à compléter**, **à relire** ou **prêt pour
relecture**. Le formateur examine vos pièces et décide du statut pédagogique.
Ni une case cochée ni un export ne vaut validation.

Pour le module 02, apportez le prompt utilisé, le résultat obtenu et une
difficulté précise. Le prompt 9 vous aide à préparer une question et une
amélioration. Aucune date ni horaire de séance supplémentaire n’est fixé ici.

## 9. Supports associés

- [Index validé](INDEX-supports-seance-04.md).
- [Liaison validée](liaison-fin-seance-03-vers-seance-04.md).
- [Prompts Markdown](support-seance-04-prompts-exercices-a-copier.md).
- [Prompts HTML avec boutons Copier](support-seance-04-prompts-exercices-a-copier.html).
- [Site de l’atelier](https://elhisse-clprepas.github.io/Atelier-seance-04-05-0ctobre-2026/).

Le PDF des prompts reprend les mêmes neuf blocs que le Markdown. Le présent
document a été harmonisé avec les supports validés ; son approbation pédagogique
reste à renseigner par le formateur.
