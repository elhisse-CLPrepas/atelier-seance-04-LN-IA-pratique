﻿# Supports de la séance 04 du module 01

**Challenge 100 Jours — Relance Automne 2026**  
**Atelier LN-IA — Module 01 : cadrage et prise de conscience**  
**Séance 04 : lundi 05 octobre 2026 — Horaire à confirmer**  
**Thème : produire, contrôler et s’engager — Durée proposée : 100 minutes**  
**Dossier : `supports-séance-04-Module01`**  
**Version : V3 — Mise à jour : 04 octobre 2026**  
**Statut du présent README : VALIDÉ POUR DIFFUSION**

Ce dossier réunit les supports de préparation, les modèles et les sources de la séance 04. Le candidat passe de son objectif et de sa carte des usages IA à un premier livrable corrigé, un engagement personnel et une preuve datée. L’[index des supports](INDEX-supports-seance-04.md) présente le déroulé et les ressources actuelles.

## 1. Par où commencer

1. Lire l’[index validé](INDEX-supports-seance-04.md) pour choisir les supports utiles.
2. Préparer le premier essai avec la [liaison entre les séances 03 et 04](liaison-fin-seance-03-vers-seance-04.md).
3. Personnaliser le [modèle d’engagement](modele-phrase-engagement-personnel.md) : livrable, public, contrôle, rythme et échéance choisie ou à confirmer.
4. Utiliser la [checklist V3](checklist-preuves-module-01.md) pour réunir les preuves et préparer leur relecture.
5. Ouvrir le [site de l’atelier](https://elhisse-clprepas.github.io/Atelier-seance-04-05-0ctobre-2026/) pour la présentation, la démonstration, le carnet et les ressources.

## 2. Inventaire et statuts des fichiers présents

### Documents actualisés

| Document | Usage | Statut constaté |
| --- | --- | --- |
| [README des supports](README-supports-seance-04.md) | Orientation, inventaire et consignes d’utilisation. | V3 — VALIDÉ POUR DIFFUSION sur instruction du formateur. |
| [Index des supports](INDEX-supports-seance-04.md) | Déroulé de 100 minutes, ressources et choix de diffusion. | V3 — VALIDÉ POUR DIFFUSION. |
| [Liaison entre les séances 03 et 04](liaison-fin-seance-03-vers-seance-04.md) | Préparer le premier essai, la correction, l’engagement et les preuves. | V3 — VALIDÉ POUR DIFFUSION. |
| [Modèle de phrase d’engagement](modele-phrase-engagement-personnel.md) | Quatre rubriques à personnaliser : engagement, responsabilité, preuves, régularité. | V3 — VALIDÉ POUR DIFFUSION ; les engagements individuels restent à relire. |
| [Checklist des preuves](checklist-preuves-module-01.md) | Réunir les pièces, documenter un contrôle et consigner la décision humaine. | V3 — modèle actualisé et contrôlé ; approbation du formateur restant à renseigner. |
| [Affiche des étapes](affiche-etapes-seance-04-v2-05-octobre-2026.png) | Visuel avec la date « LUNDI 05 OCTOBRE 2026 » et le logo LN-IA. | V2 actualisée ; ne fixe ni l’horaire ni le minutage de chaque séquence. |

### Sources complémentaires restant à réviser ou à contrôler

| Document | État et utilisation |
| --- | --- |
| [Document candidats V3](seance-04-document-candidats.md) | Harmonisé avec les quatre pièces, le déroulé de 100 minutes et les supports validés ; à relire. |
| [Guide formateur V3](seance-04-guide-atelier-formateur.md) | Déroulé de 100 minutes et contrôles pédagogiques ; prêt pour relecture du formateur. |
| [Prompts Markdown V3](support-seance-04-prompts-exercices-a-copier.md) | Neuf prompts harmonisés ; source des textes, à relire. |
| [Prompts HTML V3](support-seance-04-prompts-exercices-a-copier.html) | Mêmes textes avec copie et sélection manuelle de secours ; interactions à vérifier. |
| [Prompts PDF V3](support-seance-04-prompts-exercices-a-copier.pdf) | Dix pages régénérées depuis les neuf prompts Markdown V3 ; textes et rendu visuel contrôlés ; contenu à relire par le formateur. |

Les documents candidats et formateur portent désormais des noms sans date historique. Leur contenu V2 reste à harmoniser avant diffusion. Les anciennes copies Word et l’affiche V1 ne sont plus présentes dans ce dossier. Elles ne sont pas proposées comme supports disponibles.

Le guide actuel du module 01 en Word/PDF, le conducteur actuel et les modèles ZIP sont accessibles depuis l’index et le site. Leur présence ne vaut pas réalisation des preuves d’un candidat.

## 3. Les quatre pièces attendues à la fin de la séance

- Le **prompt réellement utilisé**, conservé et identifiable.
- Le **livrable corrigé**, enregistré et retrouvable.
- La **preuve datée**, indiquant le fichier rouvert, le contrôle effectué et le point restant à confirmer.
- L’**engagement personnel**, relu et adapté aux disponibilités du candidat.

Le brouillon et le journal de correction restent accessibles pour expliquer le travail. Un export regroupé convient si les quatre pièces sont clairement distinguées.

## 4. Confidentialité et responsabilité humaine

Utilisez un pseudonyme dans les pièces partageables. La fiche nominative, les coordonnées et les signatures restent dans un espace privé et sont remises séparément par le canal convenu avec le formateur. Les productions réelles contenant des données personnelles ne sont pas déposées sur le site public ou dans le dépôt GitHub.

L’IA peut aider à cadrer et à rédiger. Le candidat choisit ses données, vérifie les affirmations, explique ses corrections et décide de ce qu’il partage. Le cas de démonstration Madame Samira est fictif ; un exemple préparé ne remplace pas une production personnelle.

Une case cochée, un téléchargement ou un export ne valide pas le module. Le formateur examine les pièces et consigne sa décision. Les contrôles et dates doivent correspondre à des actions réellement effectuées.

## 5. Provenance et validation du README

La sélection initiale indiquait le dossier source `05-PROGRAMME-PEDAGOGIQUE/MODULE-01/supports-seance-04` et la date historique du 06 juillet 2026. Ces mentions décrivent la provenance initiale ; elles ne constituent pas des chemins de téléchargement actuels.

La présente V3 remplace l’inventaire V2 : date de séance harmonisée, fichiers présents recensés, statuts distingués et liens locaux vérifiés. L’index a été corrigé pour référencer le nom actuel `README-supports-seance-04.md`.

**Décision sur le présent README V3 : VALIDÉ POUR DIFFUSION — 04 octobre 2026.**

Validation enregistrée conformément à l’instruction du formateur dans cette conversation. Elle porte sur ce README et ne valide pas automatiquement les sources V2, la checklist encore à approuver ou les travaux individuels des candidats.

