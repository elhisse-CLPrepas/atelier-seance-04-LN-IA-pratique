﻿# Index des supports de la séance 04

**Challenge 100 Jours — Relance Automne 2026**
**Atelier LN-IA — Module 01 : cadrage et prise de conscience**
**Séance 04 : lundi 05 octobre 2026 — Horaire à confirmer**
**Thème : produire, contrôler et s’engager — Durée proposée : 100 minutes**
**Version : V3 — Mise à jour : 04 octobre 2026**

Cet index permet de retrouver les supports, de préparer la séance et de sélectionner les documents à diffuser. Les références locales sont contrôlées. Le formateur a déclaré cet index VALIDÉ POUR DIFFUSION le 04 octobre 2026. Le dossier porte désormais le nom `supports-séance-04-Module01`.

## 1. Supports actuels à utiliser en priorité

| Support | Accès | Usage et état |
| --- | --- | --- |
| Site de l’atelier | [Ouvrir le site](https://elhisse-clprepas.github.io/Atelier-seance-04-05-0ctobre-2026/) | Sept vues, présentation de 20 écrans, démonstration, carnet et ressources. Publication vérifiée lors du contrôle du projet. |
| Checklist du module 01 | [Checklist V3](checklist-preuves-module-01.md) | Preuves, contrôle daté et décision du formateur. Modèle actualisé, sans preuve candidat cochée par anticipation. |
| Affiche des étapes | [Affiche du 05 octobre 2026](affiche-etapes-seance-04-v2-05-octobre-2026.png) | Visuel actualisé avec la date « LUNDI 05 OCTOBRE 2026 » et le logo LN-IA. Repères de séance ; le conducteur actuel fixe le minutage. |
| Guide complet du module 01 | [PDF](../atelier-seance-04-LN-IA/public/ressources/guide-complet-module-01-LN-IA.pdf) · [Word](../atelier-seance-04-LN-IA/public/ressources/guide-complet-module-01-LN-IA.docx) | Progression, méthode, cas fictif Madame Samira, engagement et preuves. Fichiers disponibles ; rendu Word restant à vérifier. |
| Conducteur formateur actuel | [Conducteur de séance](../atelier-seance-04-LN-IA/public/ressources/guide-formateur-seance-04.md) | Déroulé pratique de 100 minutes. Référence d’animation actuelle. |
| Modèles candidats | [Dossier ZIP](../atelier-seance-04-LN-IA/public/ressources/modeles-candidat-module-01.zip) | Modèles vierges à compléter dans le dossier personnel. Leur présence ne constitue pas une preuve réalisée. |
| Fiche de preuves simplifiée | [Modèle de preuves](../atelier-seance-04-LN-IA/public/modeles/preuves-module-01.md) | Fichiers, contrôle daté et décision humaine. La checklist V3 détaille les critères. |

Les six prompts actuels sont proposés dans « Ressources » sur le site. Les exemples de Madame Samira sont fictifs et ne remplacent pas la production personnelle du candidat.

## 2. Supports complémentaires et sources à relire

| Support présent dans ce dossier | Rôle | Action avant diffusion |
| --- | --- | --- |
| [Liaison entre les séances 03 et 04](liaison-fin-seance-03-vers-seance-04.md) | Préparer le premier essai, l’engagement, la correction et les preuves. | V3 actualisée le 04 octobre 2026 — VALIDÉ POUR DIFFUSION sur instruction du formateur. |
| [Modèle de phrase d’engagement](modele-phrase-engagement-personnel.md) | Engagement, responsabilité, preuves et régularité ; livrable, contrôle, rythme et échéance à personnaliser. | V3 actualisée le 04 octobre 2026 — VALIDÉ POUR DIFFUSION sur instruction du formateur. |
| [Document candidats V3](seance-04-document-candidats.md) | Produire, contrôler, s’engager et remettre quatre pièces. | V3 harmonisée avec les supports validés ; à relire par le formateur. |
| [Guide formateur V3](seance-04-guide-atelier-formateur.md) | Conduite de 100 minutes, démonstration, quatre pièces et grille de relecture. | V3 harmonisée ; prête pour relecture du formateur. |
| [Prompts Markdown V3](support-seance-04-prompts-exercices-a-copier.md) | Neuf prompts de cadrage, engagement, production, correction, preuves et suite. | Source des textes harmonisée ; à relire par le formateur. |
| [Prompts HTML V3](support-seance-04-prompts-exercices-a-copier.html) | Mêmes neuf prompts avec copie et sélection manuelle de secours. | Texte synchronisé avec le Markdown ; interactions navigateur à vérifier. |
| [Prompts PDF V3](support-seance-04-prompts-exercices-a-copier.pdf) | Mêmes neuf prompts en version imprimable. | PDF régénéré ; textes et rendu des dix pages contrôlés ; contenu à relire par le formateur. |
| [README des supports](README-supports-seance-04.md) | Orientation, inventaire actuel, provenance et consignes de diffusion. | V3 actualisée le 04 octobre 2026 — VALIDÉ POUR DIFFUSION sur instruction du formateur. |

Les anciennes copies Word citées dans le README de sélection et `affiche-etapes-seance-04-v1.png` ne sont pas présentes dans le dossier au contrôle du 04 octobre 2026. Elles ne sont pas proposées comme téléchargements. Leur absence ne remet pas en cause la disponibilité du guide actuel Word/PDF dans le dossier du site.

## 3. Progression du module 01

| Séance | Date | Travail et trace attendus |
| --- | --- | --- |
| 01 | 25 septembre 2026 | Entrer dans le Challenge : projet, fiche de départ et premières notes. |
| 02 | 28 septembre 2026 | Clarifier l’objectif, le public et trois productions possibles. |
| 03 | 02 octobre 2026 | Choisir trois usages IA, les livrables, les risques et les contrôles humains. |
| 04 | 05 octobre 2026 | Tester un usage, corriger un livrable, rédiger un engagement et classer une preuve datée. |

La séance 04 clôture le module 01 par une production observable et un contrôle expliqué. Pour préparer le module 02, le candidat conserve son prompt, le résultat obtenu et une difficulté précise. Aucune date supplémentaire n’est annoncée ici.

## 4. Préparation et déroulé de séance

Avant la séance, le candidat retrouve son objectif et sa carte des usages, choisit un premier essai et prépare les informations autorisées. Il reçoit la checklist, les modèles utiles et les consignes de remise de la fiche privée.

| Durée | Séquence | Résultat attendu |
| --- | --- | --- |
| 10 min | Choisir l’essai | Objectif reformulé et premier fichier choisi. |
| 15 min | Formaliser l’engagement | Livrable, rythme réaliste, contrôle et preuve prévus. |
| 30 min | Produire une première version | 10 minutes de démonstration puis 20 minutes de production candidat. |
| 20 min | Contrôler et corriger | Passage initial, correction et justification conservés. |
| 15 min | Relire à deux | Extrait autorisé, retour reçu et décision notée. |
| 10 min | Classer et préparer la suite | Fichier rouvert et preuve datée renseignée. |

**Total : 100 minutes.** La présentation accompagne ces séquences et ne constitue pas un temps supplémentaire.

Référence : [cahier de l’atelier actuel](../atelier-seance-04-LN-IA/docs/CAHIER-ATELIER.md).

## 5. Quatre pièces à remettre

1. **Le prompt réellement utilisé**, identifiable et conservé.
2. **Le livrable corrigé**, enregistré et retrouvable.
3. **La preuve datée**, avec le fichier rouvert, le contrôle effectué et le point restant à confirmer.
4. **L’engagement personnel**, relu, lié au livrable et adapté aux disponibilités du candidat.

Le brouillon et le journal restent accessibles pour expliquer la correction. Un export regroupé convient si chaque pièce est identifiable. La fiche nominative, les coordonnées et les signatures restent privées et sont remises séparément par le canal convenu.

Un exemple fictif, un téléchargement ou une case cochée ne vaut pas validation du module. La [checklist V3](checklist-preuves-module-01.md) sert à l’auto-contrôle puis à la relecture humaine.

## 6. Contrôle et décision de validation de l’index

### Contrôles documentaires du 04 octobre 2026

- [x] Date harmonisée : lundi 05 octobre 2026 ; horaire laissé à confirmer.
- [x] Liens locaux vérifiés vers des fichiers présents.
- [x] Affiche V2 et checklist V3 référencées.
- [x] Quatre pièces de remise intégrées avec séparation des données privées.
- [x] Déroulé actuel de 100 minutes harmonisé avec le guide formateur V3.
- [x] Versions à relire, formats non retestés et fichiers absents signalés.

Ces cases décrivent le contrôle de l’index par ORIA. Elles ne déclarent ni la réalisation des preuves des candidats ni l’approbation pédagogique des supports.

### Suivi des supports avant leur diffusion

- [ ] Les supports retenus pour diffusion ont été sélectionnés et relus.
- [ ] Les sources V2 retenues ont été harmonisées avec le déroulé actuel.
- [ ] Les formats distribués ont été ouverts et contrôlés.
- [ ] Les consignes et le canal privé de remise sont confirmés.

**Statut de l’index : VALIDÉ POUR DIFFUSION.**

- Décision : **VALIDÉ POUR DIFFUSION**.
- Validation communiquée par : **le formateur, dans cette conversation**.
- Date de la décision : **04 octobre 2026 — Africa/Casablanca**.
- Périmètre : **le présent index V3**.
- Suivi : les états et réserves propres aux supports restent ceux indiqués dans les sections 1 et 2. Les contrôles complémentaires ci-dessus ne sont pas cochés automatiquement par cette décision.

La validation de l’index ne valide pas automatiquement chaque source historique ni les travaux des candidats.

